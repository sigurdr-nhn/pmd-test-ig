# Home - Pasientens måledata v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://utviklerportal.test.nhn.no/informasjonstjenester/pasientens-maaledata/pmd/ig/observation/ImplementationGuide/fhir.nhn.no.observation | *Version*:0.1.0 |
| Draft as of 2026-11-09 | *Computable Name*:pmd |

### Pasientens måledata

Pasientens måledata er en tjeneste for å dele observasjoner av pasienter mellom virksomheter.

Typiske målinger kan være vitale målinger, scoringer/ skjemaresultater.

### Mål

Alle måletyper som støttes av tjenesten vil dokumenteres som profiler av Observation, og hvordan utvekslingen foregår er dokumentert gjennom denne IG.

### Omfang

Denne implementasjonsguiden dekker følgende områder:

* Kliniske observasjoner

### Brukstilfeller

* Deling av målinger fra kommunal DHO med sykehus og fastlege
* Deling av pasientbesvarte skjema-scores med helsepersonell

#### Kliniske observasjoner

Guiden viser hvordan kliniske observasjoner som blodtrykk, puls og temperatur kan representeres ved hjelp av FHIR `Observation`-ressursen.

### Figur

Eksempel på en figur laget med PlantUML.

![](test.svg)

