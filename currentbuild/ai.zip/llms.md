# fhir.nhn.no.observation#0.1.0: Pasientens måledata

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Blodtrøkk](StructureDefinition-pmd-observation-blodprove.md)
* [Pasient](StructureDefinition-pmd-patient.md)

### ImplementationGuides

* [Pasientens måledata](index.md)

### Examples

* [Pasient-1 (Patient)](Patient-Pasient-1.md)
